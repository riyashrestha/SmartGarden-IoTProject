#step3.py
import RPi.GPIO as GPIO
from time import sleep

LedPin = 18     #Setting pin 18 to led

def setup():
    GPIO.setwarnings(False)
    GPIO.setmode(GPIO.BOARD) ## Use board pin numbering
    GPIO.setup(LedPin, GPIO.OUT) ## Setup LedPin to OUT

def loop():
    while 1:
        tempfile = open("/sys/bus/w1/devices/28-01203971a171/w1_slave") #opening temperature input file
        temptext = tempfile.read();     #reading temperature
        tempfile.close()
        tempdata = temptext.split("\n")[1].split(" ")[9]
        temperature = float(tempdata[2:])
        temperature = (temperature / 1000) * 9.0 / 5.0 + 32.0 #temperature in fahrenheit
        temperature = round(temperature, 2)
        print (temperature)
        if temperature > 75:
            GPIO.output(LedPin,True)
        else:
            GPIO.output(LedPin,False)
        sleep(1)

def destroy():
    GPIO.output(LedPin, GPIO.LOW)
    GPIO.cleanup()

if __name__ == '__main__':
    setup()
    try:
        loop()
    except KeyboardInterrupt:
        destroy()
